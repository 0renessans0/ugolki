import sys
from PyQt6.QtWidgets import QApplication, QMainWindow, QGraphicsView, QGraphicsScene, QGraphicsEllipseItem, QGraphicsRectItem, QLabel, QVBoxLayout, QWidget
from PyQt6.QtGui import QPen, QBrush, QPainter
from PyQt6.QtCore import QRectF, Qt


class Piece(QGraphicsEllipseItem):
    def __init__(self, board, x, y, color):
        super().__init__(-board.tile_size / 2, -board.tile_size / 2, board.tile_size - 2, board.tile_size - 2)
        self.board = board
        self.setPos(x*board.tile_size + board.tile_size / 2, y*board.tile_size + board.tile_size / 2)
        self.setBrush(QBrush(color))
        self.position = (x, y)
        self.mouse_down=False
        self.setFlags(QGraphicsEllipseItem.GraphicsItemFlag.ItemIsMovable)
        self.setFlag(QGraphicsEllipseItem.GraphicsItemFlag.ItemSendsGeometryChanges)

    def itemChange(self, change, value):
        if change == QGraphicsEllipseItem.GraphicsItemChange.ItemPositionChange and self.scene():
            newPos = value
            gridSize = self.board.tile_size
            xV = round((newPos.x() - gridSize / 2) / gridSize) * gridSize + gridSize / 2
            yV = round((newPos.y() - gridSize / 2) / gridSize) * gridSize + gridSize / 2
            newPos.setX(xV)
            newPos.setY(yV)
            return newPos
        return super().itemChange(change, value)

    def mousePressEvent(self, event):
        self.board.clearMoveIndicators()

        if event.button() == Qt.MouseButton.LeftButton:
            self.board.showMoves(self)

        event.ignore()

    def move(self, x, y):
        self.setPos(x * self.board.tile_size + self.board.tile_size / 2,
                    y * self.board.tile_size + self.board.tile_size / 2)
        self.position = (int(x), int(y))

    def mouseReleaseEvent(self, event):
        self.mouse_down = False
        newPos = self.scenePos()
        newX = round(newPos.x() / self.board.tile_size)
        newY = round(newPos.y() / self.board.tile_size)
        new_position = (newX, newY)
        if (0 <= newX < self.board.board_size and
                0 <= newY < self.board.board_size and
                self.board.isFree(new_position) and
                self.board.isValidMove(self.position, new_position)):
            self.board.movePiece(self, new_position)
        else:
            self.setPos(self.position[0] * self.board.tile_size,
                        self.position[1] * self.board.tile_size)

        self.board.showMoves(self)
        super().mouseReleaseEvent(event)


class MoveIndicator(QGraphicsRectItem):
    def __init__(self, x, y, board, piece):
        super().__init__(0, 0, board.tile_size, board.tile_size)
        self.setPos(x * board.tile_size, y * board.tile_size)
        self.setBrush(QBrush(Qt.GlobalColor.green))
        self.piece = piece

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            new_x = int(self.x() / self.piece.board.tile_size)
            new_y = int(self.y() / self.piece.board.tile_size)
            self.piece.move(new_x, new_y)
            self.piece.board.clearMoveIndicators()

class Board(QGraphicsView):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.scene = QGraphicsScene()
        self.setScene(self.scene)
        self.board_size = 8
        self.tile_size = 60
        self.score_black = 0
        self.score_white = 0
        self.current_player = Qt.GlobalColor.black
        self.pieces = []
        self.initUI()

    def initUI(self):
        self.drawBoard()
        self.placePieces()

    def isValidMove(self, start, end):
        dx, dy = end[0] - start[0], end[1] - start[1]
        if (abs(dx) == 1 and dy == 0) or (dx == 0 and abs(dy) == 1) or (abs(dx) == 1 and abs(dy) == 1):
            return self.isFree(end)
        elif (abs(dx) == 2 and dy == 0) or (dx == 0 and abs(dy) == 2) or (abs(dx) == 2 and abs(dy) == 2):
            mid_x = (start[0] + end[0]) // 2
            mid_y = (start[1] + end[1]) // 2
            if not self.isFree((mid_x, mid_y)) and self.isFree(end):
                return True
        return False

    def getValidMoves(self, piece):
        moves = []
        jumps = []
        x, y = piece.position
        for dx in [-1, 1]:
            if 0 <= x + dx < self.board_size:
                if self.isFree((x + dx, y)):
                    moves.append((x + dx, y))
        for dy in [-1, 1]:
            if 0 <= y + dy < self.board_size:
                if self.isFree((x, y + dy)):
                    moves.append((x, y + dy))

        if len(moves) <= 2:
            jumps = self.getValidJumps(piece)

        return moves + jumps

    def isValidJump(self, start, end):
        dx, dy = end[0] - start[0], end[1] - start[1]
        if (abs(dx) == 2 and dy == 0) or (dx == 0 and abs(dy) == 2) or (abs(dx) == 2 and abs(dy) == 2):
            mid_x, mid_y = (start[0] + end[0]) // 2, (start[1] + end[1]) // 2
            if self.getPieceAt(mid_x, mid_y) and self.isFree(end):
                return True
        return False

    def getValidJumps(self, piece):
        jumps = []
        x, y = piece.position
        directions = [(dx, dy) for dx in (-2, 0, 2) for dy in (-2, 0, 2) if (dx, dy) != (0, 0)]
        for dx, dy in directions:
            new_x, new_y = x + dx, y + dy
            if self.isValidJump((x, y), (new_x, new_y)):
                jumps.append((new_x, new_y))
        return jumps


    def showMoves(self, piece):
        self.clearMoveIndicators()
        moves = self.getValidMoves(piece)
        for move in moves:
            if self.isFree(move):
                indicator = MoveIndicator(move[0], move[1], self, piece)
                self.scene.addItem(indicator)

    def movePiece(self, piece, new_pos):
        if piece.brush().color() != self.current_player:
            return

        piece.setPos(new_pos[0] * self.tile_size, new_pos[1] * self.tile_size)
        piece.position = new_pos
        if self.checkForWin():
            self.handleWin()
        else:
            self.updateScore()
            self.switchPlayer()
        self.parent().updateStatusBar()


    def isFree(self, pos):
        return self.getPieceAt(*pos) is None

    def getPieceAt(self, x, y):
        for piece in self.pieces:
            if piece.position == (x, y):
                return piece
        return None

    def drawBoard(self):
        for x in range(self.board_size):
            for y in range(self.board_size):
                color = Qt.GlobalColor.gray if (x + y) % 2 == 0 else Qt.GlobalColor.lightGray
                self.scene.addRect(x*self.tile_size, y*self.tile_size,
                                   self.tile_size, self.tile_size,
                                   QPen(Qt.GlobalColor.black), color)

    def placePieces(self):
        color = Qt.GlobalColor.black
        for y in range(3):
            for x in range(3):
                self.create_piece((x, y), color)
                self.create_piece((self.board_size - 1 - x, self.board_size - 1 - y), Qt.GlobalColor.white)

    def create_piece(self, position, color):
        piece = Piece(self, position[0], position[1], color)
        self.pieces.append(piece)
        self.scene.addItem(piece)

    def switchPlayer(self):
        self.current_player = Qt.GlobalColor.white if self.current_player == Qt.GlobalColor.black else Qt.GlobalColor.black

    def updatePieces(self):
        pass
    def clearMoveIndicators(self):
        for item in list(self.scene.items()):
            if isinstance(item, MoveIndicator):
                self.scene.removeItem(item)

    def updateScore(self):
        self.score_black = sum(1 for piece in self.pieces if
                               piece.brush().color() == Qt.GlobalColor.black and self.isInOppositeCorner(piece.position,
                                                                                                         Qt.GlobalColor.black))
        self.score_white = sum(1 for piece in self.pieces if
                               piece.brush().color() == Qt.GlobalColor.white and self.isInOppositeCorner(piece.position,
                                                                                                         Qt.GlobalColor.white))

    def isInOppositeCorner(self, position, color):
        x, y = position
        if color == Qt.GlobalColor.black:
            return x >= self.board_size - 3 and y >= self.board_size - 3
        else:
            return x < 3 and y < 3

    def checkForWin(self):
        blacks_in_place = sum(1 for piece in self.pieces if
                              piece.brush().color() == Qt.GlobalColor.black and piece.position[
                                  0] >= self.board_size - 3)
        whites_in_place = sum(
            1 for piece in self.pieces if piece.brush().color() == Qt.GlobalColor.white and piece.position[0] < 3)

        win_condition_count = 1
        if blacks_in_place == win_condition_count or whites_in_place == win_condition_count:
            return True
        return False

    def handleWin(self):
        self.updateScore()
        winner = 'Черные' if self.score_black > self.score_white else 'Белые'
        if self.score_black == self.score_white:
            winner = 'Ничья'
        msgBox = QMessageBox()
        msgBox.setWindowTitle("Уголки")
        msgBox.setText(f"Игра окончена. Победили {winner}!")
        msgBox.exec()
        QApplication.instance().quit()

class Game(QMainWindow):
    def __init__(self):
        super().__init__()
        self.board = Board(self)
        self.status_bar = QLabel("Счет: Черные - 0, Белые - 0", self)

        layout = QVBoxLayout()
        layout.addWidget(self.status_bar)
        layout.addWidget(self.board)

        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

        self.initUI()

    def initUI(self):
        self.setWindowTitle("Игра Уголки")
        self.setGeometry(300, 300, self.board.board_size * self.board.tile_size + 5,
                         self.board.board_size * self.board.tile_size + 25)
        self.updateStatusBar() 

    def updateStatusBar(self):
        self.status_bar.setText(f'Счет: Черные - {self.board.score_black}, Белые - {self.board.score_white}')


if __name__ == "__main__":
    app = QApplication(sys.argv)
    game = Game()
    game.show()
    sys.exit(app.exec())